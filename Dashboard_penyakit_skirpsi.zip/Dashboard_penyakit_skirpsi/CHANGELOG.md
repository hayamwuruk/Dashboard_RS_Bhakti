# Change Log

## [1.0.0] 2022-06-24
### Initial Release

- UI Kit: Soft Dashboard Tailwind v1.0.2

