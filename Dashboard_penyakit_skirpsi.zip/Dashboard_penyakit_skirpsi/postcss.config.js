module.exports = {
   plugins: {
      tailwindcss: { config: "./tailwindcss-config.js" },
      autoprefixer: {},
   },
};
